package com.confrerie.confrerie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfrerieApplicationTests {

	@Test
	void contextLoads() {
	}

}
